/*
 * capteur_one_wire.c
 *
 *
 */

#include <lib_lcd.h>
#include "usart.h"
#include "main.h"
#include "tim.h"

#define MAXTIMINGS 85

//uint8_t data[5];
uint8_t _pin, _type, _count = 6;
unsigned long _lastreadtime;
/*

GPIOA_MODER=
GPIOA_OTYPER=
GPIOA_PUPDR=
GPIOA_IDR=
GPIOA_ODR=
*/

void setPinOutPut0(unsigned char x){
	/* La fonction configure la pin passee en parametre en sortie pull up et met la ligne au niveau bas
	 * MODER= 01//output 2bit
	 * OTYPER= 0 push pull 1bit
	 * PUPDR= 01 pull up 2bits
	 */

	GPIOA->MODER=((GPIOA->MODER) | (0x1<<(2*x))) & ~(0x1<<(2*x+1));
	GPIOA->OTYPER=GPIOA->OTYPER & ~(1<<x);
	GPIOA->PUPDR=(GPIOA->PUPDR | (0x1<<(2*x))) & ~(0x1<<(2*x+1));
	GPIOA->ODR=GPIOA->ODR& ~(1<<x); //met la ligne au niveau bas
}

void setPinInput1(unsigned char x){
    /* La fonction configure la pin passee en parametre en entree pull up
     * MODER= 00 //input
     * PUPDR= 01 //pull up
	 */

	GPIOA->PUPDR=GPIOA->PUPDR & 0xFFDFFFFF;
	GPIOA->PUPDR=GPIOA->PUPDR | (0x1<<20);
	GPIOA->MODER=GPIOA->MODER & 0xFFCFFFFF;

}

int getPinInput(unsigned char x){
    /* La fonction retourne la valeur lue sur la broche en entr�e (1 ou 0)
     * GPIOA_IDR
	 */
	return((int)(GPIOA->IDR& 0x400)>>10);
}

void start_one_wire(unsigned char pin)
{
	/* Le master met � 0 pendant 480us
	 * delai de 15 � 60 us,
	 * le ou les esclaves raccords forcent le bus � l'�tat bas pendant 60 � 240 xs pour signaler leur pr�sence
	*/

	setPinOutPut0(pin);
	HAL_Delay(1); //1ms
	setPinInput1(pin);
	delay_us (30); //30 us Tgo Bus master has released time
	delay_us (80); //80 us Trel Response to low time
	delay_us (80); //80 us Treh In response to high time
	delay_us (100);
}

void read_byte (uint8_t *data)
  {
  	int i, k;
  	*data=0;
  	for (i=0;i<8;i++)
  	{
  		//*data= (*data)|(getPinInput(10)<<(7-i));
  		if (HAL_GPIO_ReadPin (GPIOA, GPIO_PIN_10) == GPIO_PIN_RESET)    // if the pin is low
  		{
  			(*data)&= ~(1<<(7-i));   // write 0
  			while(!(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10)));
  			delay_us (50);
  		}
  		else
  		{
  			(*data)|= (1<<(7-i));  // if the pin is high, write 1
  			for (k=0;k<100;k++)
  			{
  				if (HAL_GPIO_ReadPin (GPIOA, GPIO_PIN_10) == GPIO_PIN_RESET)
  				  {
  				  	break;
  				  }
  			}
  			while(!(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10)));
  			delay_us (50);
  		}
  	 }
  }

void read_one_wire(uint8_t * data)
{
	for (int i=0;i<5;i++)
	{
		read_byte(&data[i]);
	}
}

void conversion(uint8_t * data, float * temp_partE, float * temp_partD, float * hum_partE, float * hum_partD)
{
	uint16_t hum= 0, temp= 0;

	hum= (data[0]<<8)|data[1];
	temp= (data[2]<<8)|data[3];

	//Calcul de l'humidite
	*hum_partE= hum/10 ;
	*hum_partD = ((hum%10)+48);

	//Calcul de la temperature
	*temp_partE = temp/10 ;
	*temp_partD = ((temp%10)+48);
}




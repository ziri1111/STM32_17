/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lib_lcd.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "capteur_one_wire.h"


/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
static rgb_lcd lcdData;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
static const uint8_t SHT31_ADDR = 0x44 << 1; // Use 8-bit address
static const uint8_t REG_TEMP = 0x86;
static const uint8_t REG_HUM = 0x86;

uint16_t RH = 0, TEMP = 0, RH2 = 0, TEMP2 = 0;

uint8_t dataH1;
uint8_t dataH2;
uint8_t dataT1;
uint8_t dataT2;
uint8_t data_parity;
uint8_t data_one_wire[5];

char parity;
GPIO_PinState state;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
/*	HAL_StatusTypeDef ret;
	  uint8_t buf[12];
	  int16_t val;
	  double temp_c;*/
	char buffer_temp[50];
		char buffer_hum[50];
		float t_partE, t_partD,h_partE, h_partD;

		 char buffer[100];
		  //char buffer2[10];
		  float temp;
		  double hum;
		  unsigned int val;
		  unsigned int valH;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start(&htim1);
  lcd_init(&hi2c1, &lcdData); // initialise le lcd
  lcd_position(&hi2c1,0,0);
  	  		  		lcd_print(&hi2c1,"coucou ");
  	  		  	HAL_Delay(2000);
  	  	clearlcd();

    //reglagecouleur(0,0,255);
    HAL_Delay(1000);
    unsigned char data[4];
    /*unsigned char* donnees;
    donnees=data;*/

    data[0]= 0x2C;
    data[1]=0x06;
    data[2]=0x00;
    data[3]=0x00;
    //HAL_I2C_Master_Transmit(&hi2c1,0x44<<1,data,2,1000);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  //lcd_position(&hi2c1,0,0);
	  	 // lcd_print(&hi2c1,"ferme  bien");
	  	  //lcd_position(&hi2c1,0,1);
	  	  //lcd_print(&hi2c1,"10h");
	  	  //reglagecouleur(255,0,255);
	  	lcd_position(&hi2c1,0,0);
	  		  		lcd_print(&hi2c1,"Test1 ");HAL_Delay(2000);
	  	clearlcd();

	  	  	/**start_one_wire(10);
	  	  	read_one_wire(data_one_wire);
	  		conversion(data_one_wire, &t_partE, &t_partD, &h_partE, &h_partD );

	  		lcd_position(&hi2c1,0,0);
	  			  		  		lcd_print(&hi2c1,"Test2 ");HAL_Delay(2000);
	  			  		  	clearlcd();
	  		sprintf((char*)buffer_temp,"%u.%u C", (unsigned int) t_partE,(unsigned int) t_partD);
	  		sprintf((char*)buffer_hum,"%u.%u ", (unsigned int) h_partE,(unsigned int) h_partE);
//a voir
	  	//Affichage capteur
	  		lcd_position(&hi2c1,12,0);
	  		lcd_print(&hi2c1,"DHT");
	  		lcd_position(&hi2c1,12,1);
	  		lcd_print(&hi2c1,"22");

	  		//Affichage temperature
	  		lcd_position(&hi2c1,0,0);
	  		lcd_print(&hi2c1,"T= ");
	  		lcd_position(&hi2c1,3,0);
	  		lcd_print(&hi2c1,buffer_temp);

	  		//Affichage humidit�
	  		lcd_position(&hi2c1,0,1);
	  		lcd_print(&hi2c1,"H= ");
	  		lcd_position(&hi2c1,3,1);
	  		lcd_print(&hi2c1,buffer_hum);
	  		lcd_print(&hi2c1,"%");

	  		HAL_Delay(2000);*/

	  		clearlcd();

	  	// Tell TMP102 that we want to read from the temperature register
	  	data[0]=0x2C;
	    data[1]=0x06;
	  	data[2]=0x00;
	  	data[3]=0x00;
	  	HAL_I2C_Master_Transmit(&hi2c1,SHT31_ADDR,data,sizeof(data),50);
	  	HAL_Delay(800);


	   HAL_I2C_Master_Receive(&hi2c1,SHT31_ADDR | 0x01,data,4,50);

	   val = data[0]<<8 | data[1];
	   valH = data[0]<<8 | data[3];
	   temp = -45 +175 * ((float)val/65535);
	   hum = 100 * ((float)valH/65535);
	  		 	/*double stemp;
	  		 					stemp = val;
	  		 					stemp *= 175;
	  		 					stemp /= 0xffff;
	  		 					stemp = -45 + stemp;
	  		 					temp = stemp; */
	  		 	sprintf(buffer,"La Temp en C: %u\r\n", ((unsigned int) temp));

	  		 	//sprintf(&buffer, "La temp %0.2u",temp);
	  		 	lcd_position(&hi2c1,0,0);
	  		 	lcd_print(&hi2c1, buffer);


	  		 	sprintf(buffer,"L'Humidite : %u \r\n", ((unsigned int) hum));

	  		 	lcd_position(&hi2c1,1,1);
	  		 	lcd_print(&hi2c1, buffer);
	  		 	//HAL_Delay(500);


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

/*
 * capteur_one_wire.h
 *
 *
 *      Author: gaiao
 */

#ifndef SRC_CAPTEUR_ONE_WIRE_H_
#define SRC_CAPTEUR_ONE_WIRE_H_

void setPinOutPut0(unsigned char x);
void setPinInput1(unsigned char x);
int getPinInput(unsigned char x);

void start_one_wire(unsigned char pin);

void read_byte (uint8_t *data);
void read_one_wire(uint8_t * data);
void conversion(uint8_t * data, float * temp_partE, float * temp_partD, float * hum_partE, float * hum_partD);

#endif /* SRC_CAPTEUR_ONE_WIRE_H_ */
